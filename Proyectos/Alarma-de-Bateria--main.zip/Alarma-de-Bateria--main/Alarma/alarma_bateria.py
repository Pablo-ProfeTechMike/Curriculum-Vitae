import tkinter as tk
import threading
import time
import psutil
import os
import sys
from PIL import Image, ImageDraw
from pystray import Icon, MenuItem as item
from win10toast import ToastNotifier
from playsound import playsound

# Función para obtener la ruta del archivo en modo .exe
def obtener_ruta(rel_path):
    if getattr(sys, 'frozen', False):
        return os.path.join(sys._MEIPASS, rel_path)  # Para ejecutable
    return os.path.join(os.path.abspath("."), rel_path)  # Para script normal

# Definir rutas de sonido
ruta_sonido_baja = obtener_ruta("hector-acosta-amorcito-enfermito-official-video_cut.mp3")
ruta_sonido_llena = obtener_ruta("maro-jump-sound-effect_1.mp3")
# Inicializar notificador
toaster = ToastNotifier()

# Variables globales
alarma_activada = False
hilo_verificacion = None
ultimo_porcentaje = None

# Función para reproducir sonido sin abrir nuevas ventanas
def reproducir_sonido(ruta):
    threading.Thread(target=playsound, args=(ruta,), daemon=True).start()

# Función para verificar la batería
def verificar_bateria():
    global alarma_activada, ultimo_porcentaje
    while alarma_activada:
        bateria = psutil.sensors_battery()
        porcentaje = bateria.percent
        cargando = bateria.power_plugged

        # Mostrar el porcentaje actual
        estado_carga = "(Cargando)" if cargando else "(No Cargando)"
        label_bateria.config(text=f"Batería: {porcentaje}% {estado_carga}")

        # Evitar alertas repetitivas
        if porcentaje != ultimo_porcentaje:
            if porcentaje == 20 and not cargando:
                reproducir_sonido(ruta_sonido_baja)
                toaster.show_toast("Batería Baja", f"¡Batería baja! {porcentaje}%.", duration=10)

            elif porcentaje == 100 and cargando:
                reproducir_sonido(ruta_sonido_llena)
                toaster.show_toast("Batería Cargada", "Desconéctala.", duration=10)

           
            ultimo_porcentaje = porcentaje  # Guardar el último porcentaje
        
        time.sleep(30)  # Actualización cada 30s

# Función para minimizar la ventana
def minimizar():
    root.withdraw()
    threading.Thread(target= crear_icono, daemon=True).start()

# Función para mostrar la ventana nuevamente
def mostrar_ventana(icon, item):
    root.deiconify()

# Función para salir de la aplicación
def salir(icon=None, item=None):
    global alarma_activada
    alarma_activada = False
    if icon:
        icon.stop()  # Detener icono
    root.quit()
    os._exit(0)

# Función para activar/desactivar la alarma
def activar_alarma():
    global alarma_activada, hilo_verificacion

    if not alarma_activada:
        alarma_activada = True
        btn_actualizar.config(text="🔔 Alarma Activada", bg="#2ECC71")  # Verde
        label_bateria.config(text="Verificando batería...")  # Mensaje inicial
        hilo_verificacion = threading.Thread(target=verificar_bateria, daemon=True)
        hilo_verificacion.start()
    else:
        alarma_activada = False
        btn_actualizar.config(text="🔔 Activar Alarma", bg="#E74C3C")  # Rojo
        label_bateria.config(text="Batería: Verificación detenida...")  # Mensaje al desactivar

# Crear ventana
root = tk.Tk()
root.title("Alarma de Batería")
root.geometry("320x200")
root.configure(bg="#2C3E50")

# Etiqueta de batería
label_bateria = tk.Label(root, text="Verificando batería...", font=("Arial", 14), fg="white", bg="#2C3E50")
label_bateria.pack(pady=20)

# Botón para activar/desactivar la alarma
btn_actualizar = tk.Button(root, text="🔔 Activar Alarma", command=activar_alarma, bg="#E74C3C", fg="white")
btn_actualizar.pack(pady=5)

# Botón para minimizar
btn_minimizar = tk.Button(root, text="🔽 Minimizar", command=minimizar, bg="#F39C12", fg="white")
btn_minimizar.pack(pady=5)

# Botón para salir
btn_salir = tk.Button(root, text="❌ Salir", command=lambda: salir(), bg="#C0392B", fg="white")
btn_salir.pack(pady=5)

# Ejecutar la aplicación
root.mainloop()
